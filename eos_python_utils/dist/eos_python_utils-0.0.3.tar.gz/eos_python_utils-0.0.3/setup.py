from setuptools import setup

setup(
    name='eos_python_utils',
    version='0.0.3',
    url='https://github.com/travisoneill/python-utils-eos-redux',
    description='python route handling for eos-redux',
    author='Travis Oneill',
    author_email='travis.h.oneill@gmail.com',
    packages=['eos_python_utils'],
    zip_safe=False
)
